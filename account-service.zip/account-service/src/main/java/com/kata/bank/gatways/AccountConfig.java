package com.kata.bank.gatways;

import org.springframework.context.annotation.Configuration;

@Configuration
public class AccountConfig {
}
