package com.kata.bank.core.domain.business.consumer.usecase.operations;

public enum ACK {
    OK,
    KO
}
