package com.kata.bank.core.domain.technical.exception;

public class AccountException extends RuntimeException {

    public AccountException(String msg){
        super(msg);
    }

}
