package com.kata.bank.core.domain.business.consumer.usecase.operations;

public enum TRANSACTION_TYPE {
    DEPOSIT,
    WITHDRAWAL
}
